﻿using Lab03.Models;
using Lab03.Repository;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Threading.Tasks;

namespace Lab03.Controllers.User
{
    public class UserProductController : Controller
    {
        private readonly IProductRepository _productRepository;
        private readonly ICategoryRepository _categoryRepository;

        public UserProductController(IProductRepository productRepository, ICategoryRepository categoryRepository)
        {
            _productRepository = productRepository;
            _categoryRepository = categoryRepository;
        }

        // GET: UserProduct/Index
        public async Task<IActionResult> Index()
        {
            var products = await _productRepository.GetAllAsync();
            var categories = await _categoryRepository.GetAllAsync();

            foreach (var product in products)
            {
                var category = categories.FirstOrDefault(c => c.Id == product.CategoryId);
                product.CategoryName = category?.Name_ ?? "Không có";
            }

            return View(products);
        }

        // GET: UserProduct/Details/1
        public async Task<IActionResult> Details(int id)
        {
            var product = await _productRepository.GetByIdAsync(id);
            if (product == null)
            {
                TempData["ErrorMessage"] = "Sản phẩm không tồn tại!";
                return RedirectToAction(nameof(Index));
            }

            if (product.CategoryId.HasValue)
            {
                product.Category = await _categoryRepository.GetByIdAsync(product.CategoryId.Value);
            }

            return View(product);
        }

    }
}
